public enum EquipmentSlotType { MainHand, Offhand, Head, Chest, Legs, Boots, Hands, Relic, None }
