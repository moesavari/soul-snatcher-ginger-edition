public enum ItemKind { Weapon, Armor, Accessory, Consumable, Other }
