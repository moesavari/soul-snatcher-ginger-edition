using UnityEngine;

namespace Game.Core.Inventory
{
    public enum ItemKind { Weapon, Armor, Accessory, Consumable, Other }
    public enum EquipmentSlotType { MainHand, Offhand, Head, Chest, Legs, Boots, Amulet, Relic }

    [CreateAssetMenu(menuName = "Game/Item", fileName = "ItemDef")]
    public class ItemDef : ScriptableObject
    {
        [SerializeField] private string _displayName;
        [SerializeField] private ItemKind _kind = ItemKind.Other;
        [SerializeField] private EquipmentSlotType _equipSlot;
        [SerializeField] private bool _twoHanded;
        [SerializeField] private int _baseAttack;
        [SerializeField] private int _baseArmor;
        [SerializeField] private Sprite _icon;

        public string displayName => _displayName;
        public ItemKind kind => _kind;
        public EquipmentSlotType equipSlot => _equipSlot;
        public bool twoHanded => _twoHanded;
        public int baseAttack => _baseAttack;
        public int baseArmor => _baseArmor;
        public Sprite icon => _icon;
    }
}