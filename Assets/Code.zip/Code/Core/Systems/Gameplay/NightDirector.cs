using UnityEngine;

public class NightDirector : MonoSingleton<NightDirector>
{
    [SerializeField] private WaveManager _waveManager;

    [SerializeField] private NightPresetSet _nightSet;
    [SerializeField] private bool _logDebug = true;

    [SerializeField] private int _nightIndex = 0;

    public int nightIndex => _nightIndex;

    private void OnEnable()
    {
        GameEvents.NightStarted += OnNightStarted;
        GameEvents.DayStarted += OnDayStarted;
    }

    private void OnDisable()
    {
        GameEvents.NightStarted -= OnNightStarted;
        GameEvents.DayStarted -= OnDayStarted;
    }

    private void OnNightStarted()
    {
        if (_waveManager == null)
        {
            DebugManager.LogWarning("NightDirector: WaveManager is missing.", this);
            return;
        }

        NightPreset preset = ResolvePresetForCurrentNight();
        if (preset == null)
        {
            DebugManager.LogWarning($"NightDirector: No preset resolved for night index {_nightIndex}.", this);
            return;
        }

        _waveManager.SetPreset(preset);
        _waveManager.StartNight();

        if (_logDebug)
        {
            DebugManager.Log(
                $"NightDirector: Starting night {_nightIndex + 1} using preset '{preset.name}'.",
                this);
        }
    }

    private void OnDayStarted()
    {
        if (_nightSet == null || _nightSet.nightCount == 0) return;

        int oldIndex = _nightIndex;

        if (_nightIndex < _nightSet.nightCount - 1)
        {
            _nightIndex++;
        }

        if (_logDebug)
        {
            DebugManager.Log(
                $"NightDirector: Completed night {oldIndex + 1}. Next night index will be {_nightIndex} (Night {_nightIndex + 1}).",
                this);
        }
    }

    private NightPreset ResolvePresetForCurrentNight()
    {
        if (_nightSet == null || _nightSet.nightCount == 0)
        {
            DebugManager.LogWarning("NightDirector: NightPresetSet is missing or empty.", this);
            return null;
        }

        return _nightSet.GetRandomPresetForNight(_nightIndex);
    }
}
