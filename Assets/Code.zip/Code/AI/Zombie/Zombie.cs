﻿using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]

public class Zombie : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float _stopDistance = 0.5f;
    [SerializeField] private float _accel = 12f;

    [Header("Targeting")]
    [SerializeField] private Transform _primaryTarget;

    [Header("Visuals")]
    [SerializeField] private SpriteRenderer _visual;
    [SerializeField] private Transform _biteRig;
    [SerializeField] private Animator _animator;

    [Header("AudioCues")]
    [SerializeField] private AudioCue _spawnCue;

    [Header("AI Settings")]
    [SerializeField] private NPCStats _stats;
    [SerializeField] private LayerMask _zombieMask;
    [SerializeField] private bool _includeTriggers = false;
    [SerializeField] private float _separationStrength = 0.5f;
    [SerializeField] private float _separationRadius = 0.25f;
    [SerializeField] private ZombieBite _zombieBite;

    [Header("Sunrise Enraged-Burning")]
    [SerializeField] private float _burnDuration = 7f;
    [SerializeField] private float _burnDPS = 0.5f;
    [SerializeField] private float _enrageSpeedMult = 1.35f;
    [SerializeField] private GameObject _burnFxPrefab;
    [SerializeField] private float _sunKillTime = 7f;

    private Rigidbody2D _rb;
    private ContactFilter2D _filter;

    private Vector2 _vel;
    private bool _deathNotified;
    private readonly Collider2D[] _overlapBuffer = new Collider2D[16];

    private bool _isEnragedBurning;
    private bool _morgensternToten;
    private float _burnTimer;
    private float _burnDamagePool = 0f;

    private int _currentHealth;
    public int currentHealth => _currentHealth;

    private bool _isDead = false;
    private Vector2 _lastPos;

    public System.Action OnDeath;
    public System.Action OnDamaged;

    private void Awake()
    {
        _rb = this.Require<Rigidbody2D>();
        _rb.constraints = RigidbodyConstraints2D.FreezeRotation;

        _currentHealth = _stats != null ? _stats.Health : 1;

        if (_zombieBite == null) _zombieBite = GetComponentInChildren<ZombieBite>();
        if (_zombieBite != null) _zombieBite.InitBaseValues();

        if (_animator == null && _visual != null)
            _animator = _visual.GetComponent<Animator>();

        _zombieBite.SetOwner(_stats);
        _lastPos = transform.position;
    }

    private void OnEnable()
    {
        _filter = new ContactFilter2D
        {
            useLayerMask = true,
            layerMask = _zombieMask,
            useTriggers = _includeTriggers,
            useDepth = false
        };

        _deathNotified = false;

        if (_spawnCue != null) AudioManager.Instance.PlayCue(_spawnCue, worldPos: transform.position);

        if (!TimeCycleManager.Instance.isNight)
        {
            EnterEnragedForm();
        }

        GameEvents.DayStarted += OnDayStarted;
    }

    private void OnDisable()
    {
        GameEvents.DayStarted -= OnDayStarted;
    }

    private void Update()
    {
        if (_isEnragedBurning) DoBurnTick();
    }

    private void FixedUpdate()
    {
        if (_isDead)
        {

            _vel = Vector2.zero;
            if (_rb != null) _rb.linearVelocity = Vector2.zero;
            UpdateAnimator();
            return;
        }

        Transform target = ResolveTarget();

        var kb = GetComponent<KnockbackReceiver>();
        if (kb != null && kb.isStunned) return;

        if (target == null)
        {
            _vel = Vector2.MoveTowards(_vel, Vector2.zero, _accel * Time.fixedDeltaTime);
            _rb.MovePosition(_rb.position + _vel * Time.fixedDeltaTime);
            return;
        }

        Vector2 pos = _rb.position;
        Vector2 toTarget = (Vector2)target.position - pos;
        float dist = toTarget.magnitude;


        if (_visual != null) _visual.flipX = (toTarget.x < 0f);
        if (_biteRig != null && toTarget.sqrMagnitude > 0.0001f)
            _biteRig.right = toTarget.normalized;

        Vector2 desired = (dist > _stopDistance) ? toTarget.normalized * _stats.MoveSpeed : Vector2.zero;


        if (_zombieBite != null && _zombieBite.IsBiting) desired = Vector2.zero;


        ContactFilter2D filter = _filter;

        int count = Physics2D.OverlapCircle(pos, _separationRadius, filter, _overlapBuffer);

        for (int i = 0; i < count; i++)
        {
            var hit = _overlapBuffer[i];
            if (hit == null) continue;
            var otherRb = hit.attachedRigidbody;
            if (otherRb == null || otherRb == _rb) continue;

            Vector2 away = (pos - (Vector2)otherRb.position);
            float d = away.magnitude;
            if (d > 0.0001f)
            {

                float falloff = Mathf.Clamp01(1f - (d / _separationRadius));
                desired += away.normalized * (_separationStrength * falloff);
            }
        }


        float maxSpeed = _stats.MoveSpeed * (_isEnragedBurning ? _enrageSpeedMult : 1f);
        if (desired.sqrMagnitude > (maxSpeed * maxSpeed))
            desired = desired.normalized * maxSpeed;


        _vel = Vector2.MoveTowards(_vel, desired, _accel * Time.fixedDeltaTime);


        _rb.MovePosition(_rb.position + _vel * Time.fixedDeltaTime);

        UpdateAnimator();
    }

    private void UpdateAnimator()
    {
        if (_animator == null) return;


        if (_isDead)
        {
            _animator.SetBool("walk", false);
            _animator.SetBool("jump", false);
            _animator.SetBool("dead", true);
            return;
        }


        Vector2 currentPos = transform.position;
        Vector2 delta = currentPos - _lastPos;
        _lastPos = currentPos;

        bool isMoving = delta.sqrMagnitude > 0.00005f;

        _animator.SetBool("walk", isMoving);
        _animator.SetBool("jump", false);

    }

    private Transform ResolveTarget()
    {
        if (_primaryTarget != null) return _primaryTarget;
        var gmPlayer = GameManager.Instance?.player;
        return gmPlayer != null ? gmPlayer.transform : null;
    }

    private void OnDied()
    {
        if (_deathNotified) return;

        _isDead = true;

        if (_zombieBite != null) _zombieBite.SetEnraged(false);
        _isEnragedBurning = false;

        if (_morgensternToten) DebugManager.Log("Skipping Loot", this);

        _deathNotified = true;
        OnDeath?.Invoke();

        if (_animator != null)
        {
            _animator.SetBool("walk", false);
            _animator.SetBool("dead", true);
        }


        foreach (var col in GetComponentsInChildren<Collider2D>())
            col.enabled = false;


        _rb.linearVelocity = Vector2.zero;


        StartCoroutine(DeathRoutine());
    }

    private IEnumerator DeathRoutine()
    {
        yield return new WaitForSeconds(1.4f);
        Destroy(gameObject);
    }

    public void TakeDamage(int amount)
    {
        OnDamaged?.Invoke();
        _currentHealth = Mathf.Max(0, _currentHealth - Mathf.Max(0, amount));
        if (_currentHealth <= 0) OnDied();
    }

    private void OnDayStarted()
    {
        if (!isActiveAndEnabled) return;

        if (_isEnragedBurning) return;

        EnterEnragedForm();
    }

    private void EnterEnragedForm()
    {
        if (_isEnragedBurning) return;

        _isEnragedBurning = true;

        _burnDuration = _sunKillTime;
        _burnTimer = _burnDuration;
        _burnDPS = Mathf.Max(0.0001f, _stats.Health / _sunKillTime);

        _burnDamagePool = 0f;

        if (_zombieBite != null) _zombieBite.SetEnraged(true);

    }

    private void DoBurnTick()
    {
        _burnTimer -= Time.deltaTime;

        _burnDamagePool += _burnDPS * Time.deltaTime;

        int burnDamageNow = Mathf.FloorToInt(_burnDamagePool);
        if (burnDamageNow > 0 && _currentHealth > 0)
        {
            TakeDamage(burnDamageNow);
            _burnDamagePool -= burnDamageNow;
        }

        if (_burnTimer <= 0f && _currentHealth > 0)
        {
            _morgensternToten = true;
            TakeDamage(_currentHealth);
        }
    }


#if UNITY_EDITOR
    private void OnDrawGizmosSelected()
    {

        Gizmos.color = Color.white;
        Gizmos.DrawWireSphere(transform.position, _separationRadius);
        Gizmos.color = Color.clear;
    }

    private void OnValidate()
    {

        _filter.useLayerMask = true;
        _filter.layerMask = _zombieMask;
        _filter.useTriggers = _includeTriggers;
    }
#endif
}
