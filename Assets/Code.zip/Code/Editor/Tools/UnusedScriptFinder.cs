using UnityEngine;
using UnityEditor;
using System.IO;
using System.Collections.Generic;
using System.Linq;

public class UnusedScriptFinder : EditorWindow
{
    [MenuItem("Tools/Find Unused MonoBehaviour Scripts")]
    public static void ShowWindow()
    {
        GetWindow<UnusedScriptFinder>("Unused Script Finder");
    }

    private Vector2 scroll;
    private List<string> unusedScripts = new List<string>();
    private bool searched = false;

    void OnGUI()
    {
        if (GUILayout.Button("Find Unused MonoBehaviour Scripts"))
        {
            unusedScripts = FindUnusedMonoBehaviours();
            searched = true;
        }

        if (searched)
        {
            GUILayout.Label("Unused Scripts:", EditorStyles.boldLabel);
            scroll = GUILayout.BeginScrollView(scroll);
            foreach (var script in unusedScripts)
            {
                GUILayout.Label(script);
            }
            GUILayout.EndScrollView();
        }
    }

    private List<string> FindUnusedMonoBehaviours()
    {
        // Get all C# script paths
        var scriptGuids = AssetDatabase.FindAssets("t:MonoScript");
        var scriptPaths = scriptGuids.Select(AssetDatabase.GUIDToAssetPath).ToList();

        // Get all prefab and scene asset paths
        var prefabGuids = AssetDatabase.FindAssets("t:Prefab");
        var sceneGuids = AssetDatabase.FindAssets("t:Scene");
        var assetPaths = prefabGuids.Concat(sceneGuids).Select(AssetDatabase.GUIDToAssetPath).ToList();

        // Map class names to script paths
        var scriptClassNames = new Dictionary<string, string>();
        foreach (var scriptPath in scriptPaths)
        {
            MonoScript ms = AssetDatabase.LoadAssetAtPath<MonoScript>(scriptPath);
            if (ms != null && ms.GetClass() != null && ms.GetClass().IsSubclassOf(typeof(MonoBehaviour)))
            {
                scriptClassNames[ms.GetClass().Name] = scriptPath;
            }
        }

        // Look for references in prefab/scene text
        var referencedClassNames = new HashSet<string>();
        foreach (var assetPath in assetPaths)
        {
            var text = File.ReadAllText(assetPath);
            foreach (var className in scriptClassNames.Keys)
            {
                if (text.Contains(className))
                {
                    referencedClassNames.Add(className);
                }
            }
        }

        // List scripts that are not referenced
        var unused = scriptClassNames
            .Where(kvp => !referencedClassNames.Contains(kvp.Key))
            .Select(kvp => kvp.Value)
            .ToList();

        return unused;
    }
}
