using System.Collections;
using UnityEngine;

public class CanvasGroupFader : MonoBehaviour
{
    [SerializeField] private CanvasGroup _group;
    [SerializeField] private float _duration = 0.15f;

    private Coroutine _co;

    public void Fade(bool show)
    {
        if (_co != null) StopCoroutine(_co);
        _co = StartCoroutine(FadeCo(show));
    }

    private IEnumerator FadeCo(bool show)
    {
        if (!_group) yield break;
        float t = 0f;
        float start = _group.alpha;
        float end = show ? 1f : 0f;
        _group.blocksRaycasts = true;
        _group.interactable = true;
        while (t < _duration)
        {
            t += Time.unscaledDeltaTime;
            _group.alpha = Mathf.Lerp(start, end, t / _duration);
            yield return null;
        }
        _group.alpha = end;
        _group.blocksRaycasts = show;
        _group.interactable = show;
    }
}