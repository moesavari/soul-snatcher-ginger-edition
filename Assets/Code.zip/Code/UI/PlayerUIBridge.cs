using Game.Events;
using Game.UI.HUD;
using TMPro;
using UnityEngine;

public class PlayerUIBridge : MonoBehaviour
{
    [SerializeField] private TMP_Text _soulsText;
    [SerializeField] private TMP_Text _waveText;
    [SerializeField] private HealthbarUI _healthbar;

    private void OnEnable()
    {
        HealthEvents.HealthChanged += OnHealthChanged;
        GameEvents.SoulsChanged += OnSoulsChanged;
        WaveEvents.WaveChanged += OnWaveChanged;
    }
    private void OnDisable()
    {
        HealthEvents.HealthChanged -= OnHealthChanged;
        GameEvents.SoulsChanged -= OnSoulsChanged;
        WaveEvents.WaveChanged -= OnWaveChanged;
    }

    private void OnHealthChanged(int current, int max) { _healthbar?.Set(current, max); }
    private void OnSoulsChanged(int souls) { if (_soulsText) _soulsText.text = $"SOULS: {souls}"; }
    private void OnWaveChanged(int cur, int max) { if (_waveText) _waveText.text = $"Wave {cur}/{max}"; }
}