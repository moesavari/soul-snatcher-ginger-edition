public sealed class BagCellPool : UIGridPool<InventoryCellView> { }
