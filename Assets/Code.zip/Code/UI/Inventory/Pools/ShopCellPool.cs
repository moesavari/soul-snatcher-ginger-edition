public sealed class ShopCellPool : UIGridPool<ShopCellView> { }
