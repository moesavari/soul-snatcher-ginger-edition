public enum AudioChannel
{
    Music,
    SFX,
    Voice,
    Ambient,
    UI,
    Footsteps
}
