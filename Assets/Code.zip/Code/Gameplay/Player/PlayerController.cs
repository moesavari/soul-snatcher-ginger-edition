using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private float _moveSpeed = 4f;
    [SerializeField] private Animator _animator;
    [SerializeField] private Rigidbody2D _rb;

    private Vector2 _moveInput;

    private void Update()
    {
        _moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")).normalized;

        //_animator?.SetFloat("MoveX", _moveInput.x);
        //_animator?.SetFloat("MoveY", _moveInput.y);
        //_animator?.SetBool("IsMoving", _moveInput != Vector2.zero);
    }

    private void FixedUpdate()
    {
        _rb.MovePosition(_rb.position + _moveInput * _moveSpeed * Time.fixedDeltaTime);
    }
}
