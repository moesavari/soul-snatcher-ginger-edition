using UnityEngine;

[DisallowMultipleComponent]

public class MouseFacing2D : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private Transform _aimRig;
    [SerializeField] private Transform _firePoint;
    [SerializeField] private SpriteRenderer _visual;
    [SerializeField] private Transform _fallback;
    [SerializeField] private bool _isLocked;

    [Header("Debug")]
    [SerializeField] private bool _warnOnMirror = true;

    private Camera _cam;
    private Vector2 _aimDir = Vector2.right;

    public Vector2 AimDir => _aimDir;
    public bool isAimLocked => _isLocked;

    public void SetAimLocked(bool v) { _isLocked = v; }

    private void Awake()
    {
        _cam = Camera.main;
        if (_fallback == null) _fallback = transform;

        if (_aimRig == null) _aimRig = transform;
        ForcePositiveScaleChain(_aimRig);
    }

    private void Update()
    {
        if(_isLocked) return;

        if (_cam == null) { _cam = Camera.main; if (_cam == null) return; }

        Vector3 src = _firePoint ? _firePoint.position : _fallback.position;
        Vector3 mw = _cam.ScreenToWorldPoint(Input.mousePosition);
        mw.z = src.z;
        Vector2 dir = (Vector2)(mw - src);
        if (dir.sqrMagnitude < 0.000001f) return;

        _aimDir = dir.normalized;

        if (_aimRig != null)
        {
            float ang = Mathf.Atan2(_aimDir.y, _aimDir.x) * Mathf.Rad2Deg;
            _aimRig.SetPositionAndRotation(_aimRig.position, Quaternion.Euler(0, 0, ang));
        }

        if (_visual != null)
            _visual.flipX = (_aimDir.x < 0f);

#if UNITY_EDITOR
        if (_warnOnMirror) WarnIfNegativeScaleInChain(_aimRig);
#endif
    }

    private static void ForcePositiveScaleChain(Transform t)
    {
        for (var p = t; p != null; p = p.parent)
        {
            Vector3 s = p.localScale;
            if (s.x < 0f || s.y < 0f || s.z < 0f)
                p.localScale = new Vector3(Mathf.Abs(s.x), Mathf.Abs(s.y), Mathf.Abs(s.z));
        }
    }

#if UNITY_EDITOR
    private static void WarnIfNegativeScaleInChain(Transform t)
    {
        for (var p = t; p != null; p = p.parent)
        {
            Vector3 s = p.localScale;
            if (s.x < 0f || s.y < 0f || s.z < 0f)
            {
                DebugManager.LogWarning($"Negative scale on '{p.name}'. " +
                                 "This mirrors child space and causes hitbox side swaps.");
                break;
            }
        }
    }
#endif

    private void OnDrawGizmosSelected()
    {
        if (_firePoint == null || _cam == null) return;
        var mw = _cam.ScreenToWorldPoint(Input.mousePosition); mw.z = _firePoint.position.z;
        Gizmos.color = Color.cyan;
        Gizmos.DrawLine(_firePoint.position, mw);
    }
}
