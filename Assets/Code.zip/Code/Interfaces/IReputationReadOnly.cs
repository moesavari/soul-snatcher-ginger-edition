public interface IReputationReadOnly
{
    int reputation { get; }
}
