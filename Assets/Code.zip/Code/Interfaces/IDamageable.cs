public interface IDamageable
{
    int TakeDamage(int amount);
}
